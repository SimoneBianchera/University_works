package it.polimi.hand;

public class EmptyListException extends Throwable {
}
