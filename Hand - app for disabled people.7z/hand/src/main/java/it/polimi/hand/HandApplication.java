package it.polimi.hand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandApplication {

    public static void main(String[] args) {
        SpringApplication.run(HandApplication.class, args);
    }

}
